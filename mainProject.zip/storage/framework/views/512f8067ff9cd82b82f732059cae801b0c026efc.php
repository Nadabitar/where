<nav class="navbar header-navbar pcoded-header">
    <div class="navbar-wrapper">

        <div class="navbar-logo">
            <a class="mobile-menu" id="mobile-collapse" href="#!">
                <i class="ti-menu"></i>
            </a>
            <a class="mobile-search morphsearch-search" href="#">
                <i class="ti-search"></i>
            </a>
            <a href="index.html">
                <img class="img-fluid" src="<?php echo e(asset('backend/assets/images/logo.png')); ?>" alt="Theme-Logo" />
            </a>
            <a class="mobile-options">
                <i class="ti-more"></i>
            </a>
        </div>

        <div class="navbar-container container-fluid">
            <ul class="nav-left">
                <li>
                    <div class="sidebar_toggle"><a href="javascript:void(0)"><i class="ti-menu"></i></a></div>
                </li>

                <li>
                    <a href="#!" onclick="javascript:toggleFullScreen()">
                        <i class="ti-fullscreen"></i>
                    </a>
                </li>
            </ul>
            <ul class="nav-right">
                <li class="header-notification">
                    <a href="#!">
                        <i class="ti-bell"></i>
                        <span class="badge bg-c-pink"></span>
                    </a>
                    <ul class="show-notification">
                        <li>
                            <h6>Notifications</h6>
                            <a href="<?php echo e(route('Places.new')); ?>"><label class="label" style="background-color:var(--primary); cursor: pointer;">Show</label></a> 
                            <label class="label label-danger">New</label>
                        </li>
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="media">
                                <?php if($notification->data['image']): ?>
                                <img class="d-flex align-self-center img-radius" src="<?php echo e($notification->data['image']); ?>" alt="Generic placeholder image">
                                <?php else: ?>
                                <img class="d-flex align-self-center img-radius" src="<?php echo e(asset('backend/assets/images/Default_User.jpg')); ?>" alt="Generic placeholder image">
                                <?php endif; ?>
                                <div class="media-body">
                                    <h5 class="notification-user"><?php echo e($notification->data['name'] ? $notification->data['name'] : "Nada Arab Bitar"); ?></h5>
                                    
                                    <span class="notification-time"><?php echo e(\Carbon\Carbon::parse($notification->created_at)->format('H : s : i')); ?></span>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="user-profile header-notification">
                    <a href="#!">
                        
                     
                        <span>John Doe</span>
                        <i class="ti-angle-down"></i>
                    </a>
                    <ul class="show-notification profile-notification">
                        <li>
                            <a href="#!">
                                <i class="ti-settings"></i> Settings
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="ti-user"></i> Profile
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="ti-email"></i> My Messages
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="ti-lock"></i> Lock Screen
                            </a>
                        </li>
                        <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                <i class="ti-layout-sidebar-left"></i> 
                                <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/admin/layouts/nav.blade.php ENDPATH**/ ?>