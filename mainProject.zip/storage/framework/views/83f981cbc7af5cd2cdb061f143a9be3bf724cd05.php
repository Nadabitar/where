
<?php $__env->startSection('content'); ?>
<div class="main-body">
    <div class="page-wrapper">
        <!-- Page-header start -->
        <div class="page-header card">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <a href="<?php echo e(route('Place.Add')); ?>"> <i class="ti-plus bg-c-blue"></i></a>
                        <div class="d-inline">
                            <h4>Show All Products</h4>
                            <span class="badge badge-primary text-white">Total Products : <?php echo e(App\Models\Places::all()->count()); ?> </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="page-header-breadcrumb">
                       <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin')); ?>">
                                <i class="icofont icofont-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Places</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">All Places</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <!-- Page-body start -->
    <div class="page-body">
        <!-- Hover table card start -->
        <div class="card">
            <div class="card-header">
                <h5>Products table</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="icofont icofont-simple-left "></i></li>        
                        <li><i class="icofont icofont-maximize full-card"></i></li>        
                        <li><i class="icofont icofont-minus minimize-card"></i></li>        
                        <li><i class="icofont icofont-refresh reload-card"></i></li>        
                    </ul>
                </div>
            </div>
            <div class="card-block table-border-style">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>S.N</th>
                                <th>Photo</th>
                                <th>Place Name</th>
                                <th>Saved</th>
                                <th>Comments</th>
                                <th>Joining at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <img style="max-height: 98px; max-width:128px;"
                                    src="<?php echo e($place->image); ?>" alt="<?php echo e($place->placeName); ?> photo">
                                </td>
                                <td style="color: var(--primary); font-size: 16px; font-weight: 600; text-transform: capitalize" ><?php echo e($place->placeName); ?></td>
                                <td><?php echo e($place->saved ? $place->saved->count() : 0); ?></td>
                                <td><?php echo e($place->comment ? $place->comment->count() : 0); ?></th>      
                                <td>
                                    <span style="color: var(--primary)" class="badge p-2"><?php echo e($place->created_at); ?></span>
                                </td>
                                <td class="d-flex">
                                    <a href="<?php echo e(route('Place.edit' , $place->id)); ?>" class='btn btn-sm btn-outline-warning  p-1 mx-1' data-toggle="tooltip" title="edit" data-placement = "bottom"><i class="ti-pencil "></i></a>
                                    <a class='btn btn-sm btn-outline-success  p-1 mx-1' data-toggle="modal" data-target="#showProduct<?php echo e($place->id); ?>" title="view" data-placement = "bottom"><i class="ti-eye"></i></a>
                                    <form action="<?php echo e(route('Place.delete' , $place->id)); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a id="BtnDelet" class='btn btn-sm btn-outline-danger p-1 mx-1' data-id ="<?php echo e($place->id); ?>" data-toggle="tooltip" title="delete" data-placement = "bottom">
                                        <i class="ti-trash"></i></a>
                                    </form>
                                </td>
                                
                                

                                <div class="modal fade" id="showProduct<?php echo e($place->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <<?php
                                        $place = \App\Models\Places::where('id' ,$place->id)->first();
                                        $cat = new  \App\Models\Categoris();
                                    ?>
                                    <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="wrapper">
                                          
                                            <div class="profile-card js-profile-card">
                                                <div class="profile-card__img">
                                                    <img src="<?php echo e($place->image); ?>" alt="profile card">
                                                </div>
                                            
                                                <div class="profile-card__cnt js-profile-cnt">
                                                    <div class="profile-card__name"><?php echo e($place->placeName); ?></div>
                                                    <div class="profile-card__txt"> <?php echo e($place->details ? $place->details : 'No Details'); ?></div>
                                                    <div class="profile-card-loc">
                                                    <span class="profile-card-loc__icon">
                                                        <i class="ti-location-pin icon"></i>
                                                    </span>
                                            
                                                    <span class="profile-card-loc__txt">
                                                        <?php echo e($place->account->region->name); ?> - <?php echo e($place->account->streetId? $place->account->street->name : " "); ?>

                                                    </span>
                                                    </div>
                                            
                                                    <div class="profile-card-inf">
                                                    <div class="profile-card-inf__item">
                                                        <div class="profile-card-inf__title"><?php echo e($place->category->name); ?></div>
                                                        <div class="profile-card-inf__txt">Category</div>
                                                    </div>
                                            
                                                    <div class="profile-card-inf__item">
                                                        <div class="profile-card-inf__title">
                                                            <?php $__currentLoopData = $cat->getAllChildByParent($place->category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <span>  <?php echo e($item->name); ?>  </span> <Span class="sprator"> / </Span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </div>
                                                        <div class="profile-card-inf__txt">Sub Category</div>
                                                    </div>
                                            
                                                    <div class="profile-card-inf__item">
                                                        <div class="profile-card-inf__title"><?php echo e($place->phone); ?></div>
                                                        <div class="profile-card-inf__txt">Phone Number</div>
                                                    </div>
                                            
                                                    <div class="profile-card-inf__item">
                                                        <div class="profile-card-inf__title"><?php echo e($place->phone); ?></div>
                                                        <div class="profile-card-inf__txt">Addtin Phone Number</div>
                                                    </div>

                                                    <div class="profile-card-inf__item">
                                                        <div class="profile-card-inf__title"><?php echo e($place->workTime); ?></div>
                                                        <div class="profile-card-inf__txt">Work Time</div>
                                                    </div>
                                                    </div>
                                            
                                                    <div class="profile-card-social">
                                                        <a href="" class="profile-card-social__item facebook" target="_blank">
                                                            <span class="icon-font">
                                                                <i class="ti-facebook icon"><use xlink:href="#icon-facebook"></use></i>
                                                            </span>
                                                        </a>
                                                        
                                                        <a href="" class="profile-card-social__item whts" target="_blank">
                                                            <span class="icon-font">
                                                                <i class="ti-skype icon"><use xlink:href="#icon-link"></use></i>
                                                            </span>
                                                        </a>
                                                        <a href="" class="profile-card-social__item instagram" target="_blank">
                                                            <span class="icon-font">
                                                                <i class="ti-instagram icon"><use xlink:href="#icon-link"></use></i>
                                                            </span>
                                                        </a>
                                            
                                                    </div>
                                            
                                                    <div class="profile-card-ctr">
                                                        <button class="profile-card__button button--blue js-message-btn">Message</button>
                                                        <button class="profile-card__button button--orange">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
             
            </div>
        </div>
        <!-- Hover table card end -->
    </div>
    <!-- Page-body end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
     $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }   
    });
    $('#BtnDelet').click(function (e) {
        var form = $(this).closest('form');
        var dataID = $(this).data('id');
        e.preventDefault();
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true})
                .then((willDelete) => {
                if (willDelete)
                {
                    alert(dataID);
                    form.submit();
                    swal("Poof! Your imaginary file has been deleted!", {
                    icon: "success"});
                } 
                else
                {
                    swal("Your imaginary file is safe!");
                }
        });
        });
</script>


<script>
        $('input[name=toggle]').change(function(){
            var mode = $(this).prop('checked');
            var id  = $(this).val();
            // alert(id);
            $.ajax({
                url: "<?php echo e(route('Place.status')); ?>",
                type : 'post' ,
                data : {
                    _token : '<?php echo e(csrf_token()); ?>',
                    mode : mode,
                    id : id,
                },
                success:function(response){
                    if(response.status){
                    alert(response.msg);
                    }else{
                        alert('Please Try Again');
                    }
                }
            });
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/product/index.blade.php ENDPATH**/ ?>