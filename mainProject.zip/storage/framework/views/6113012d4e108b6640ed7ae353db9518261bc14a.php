
<?php $__env->startSection('content'); ?>
<div class="main-body">
    <div class="page-wrapper">
        <!-- Page-header start -->
        <div class="page-header card">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ti-arrow-left bg-c-blue"></i>
                        <div class="d-inline">
                            <h4>Show All Users</h4>
                            <span class="badge badge-primary text-white">Total Users : <?php echo e(App\Models\User::all()->count()); ?> </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="page-header-breadcrumb">
                       <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin')); ?>">
                                <i class="icofont icofont-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Users</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">All Users</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <!-- Page-body start -->
    <div class="page-body">
        <!-- Hover table card start -->
        <div class="card">
            <div class="card-header">
                <h5>Uers table</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="icofont icofont-simple-left "></i></li>        
                        <li><i class="icofont icofont-maximize full-card"></i></li>        
                        <li><i class="icofont icofont-minus minimize-card"></i></li>        
                        <li><i class="icofont icofont-refresh reload-card"></i></li>        
                    </ul>
                </div>
            </div>
            <div class="card-block table-border-style">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>S.N</th>
                                <th>Photo</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Region</th>
                                <th>Comments</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->iteration); ?></th>
                                <td>
                                    <?php if($user->gender == 'male'): ?>
                                        <img style="max-height: 98px; max-width:128px;"
                                        src="<?php echo e(asset('backend/assets/images/male.jpg')); ?>" alt="<?php echo e($user->gender); ?> user">
                                    <?php else: ?>
                                    <img style="max-height: 98px; max-width:128px;"
                                    src="<?php echo e(asset('backend/assets/images/fmale.png')); ?>" alt="<?php echo e($user->gender); ?> famle user">
                                    <?php endif; ?>
                                   
                                </td>
                                <td><?php echo e($user->fullName); ?></td>
                                <th>
                                   <?php echo e($user->email); ?>

                                </th>
                                <td>
                                    <?php echo e($user->phone); ?>

                                </td>
                                <td>
                                    <?php echo e($user->region->name); ?> <span>/ <?php echo e($user->streetId ? \App\Models\Region::where('id' , $user->streetId)->first()->name : " "); ?></span>
                                </td>
                                <td class="d-flex">
                                    <p style="cursor: pointer;" data-toggle="modal" data-target="#showuser<?php echo e($user->id); ?>" title="view" class="my-2 text-success">   <?php echo e($user->makeComment->count()); ?> Comments</p>
                                    <a class='btn btn-sm btn-outline-success  p-2 mx-1 ' data-toggle="modal" data-target="#showuser<?php echo e($user->id); ?>" title="view" data-placement = "bottom">Show All Comments</a>
                                </td>

                                
                                

                                <div class="modal fade" id="showuser<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <<?php
                                        $comments = \App\Models\user::where('id' ,$user->id)->with('makeComment')->first()->makeComment;
                                    ?>
                                    
                                    <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 style="text-transform: capitalize" class="modal-title text-center d-block" id="exampleModalLabel">Here you can see all comments for user</h5>
                                            <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">X</button>
                                        </div>
                                        <div class="modal-body">
                                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $rate = $comment->pivot->rate
                                            ?>
                                                <div class="card mb-3">
                                                    
                                                    <div class="profile-place">
                                                        <div class="right">
                                                            <img src="<?php echo e($comment->image); ?>" alt="">
                                                        </div>
                                                        <div class="left">
                                                            <div class="left-header">
                                                                <div class="place-title"><?php echo e($comment->placeName); ?></div>
                                                                <div class="place-rate">
                                                                    <?php for($i =  0 ; $i < $rate; $i++): ?>
                                                                        <i class="ti-star text-warning"></i>
                                                                    <?php endfor; ?>
                                                                </div>
                                                            </div>
                                                            <div class="left-body">
                                                                <p> <i class="ti-comment"></i> </p>
                                                                <div> <p><?php echo e($comment->pivot->content); ?></p> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <a  class="btn btn-primary text-white">Edit</a>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <!-- Hover table card end -->
    </div>
    <!-- Page-body end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/users/index.blade.php ENDPATH**/ ?>