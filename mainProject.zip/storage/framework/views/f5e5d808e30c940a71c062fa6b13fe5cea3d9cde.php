

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('subscriber.partial.navbar', ['place'=>$place , 'services' => $services], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Search Start -->
        <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 35px;">
            <div class="container">
                <div class="row g-2">
                    <h1 class="add-service-text">إضافة خدمة جديدة</h1>
                </div>
            </div>
        </div>
        <!-- Search End -->
        <?php echo $__env->make('subscriber.partial.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="add-service-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="owl-carousel header-carousel">
                    <div class="owl-carousel-item">
                        
                        <img class="img-fluid" src="<?php echo e(asset('assets/img/Subscriber/1.jpg')); ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="add-service">
                    <form enctype="multipart/form-data"  action="<?php echo e(route('Service.store' , $place->id)); ?>"  method="POST" >
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <input id="service-imag" class="form-control" type="file" name="image">
                            </div>
                            
                            </div>
                            <div class="col-md-12">
                                <div class="add-form">
                                    <input name="title" placeholder="عنوان*" type="text">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="text-details">
                                    <textarea name="content" placeholder="*وصف الخدمة"></textarea>
                                    <button class="submit" type="submit">حفظ المعلومات</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/Subscriber/vendor/jquery-1.12.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/Subscriber/vendor/modernizr-2.8.3.min.js')); ?>"></script>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('subscriber.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/subscriber/pages/Service/create.blade.php ENDPATH**/ ?>