
<?php $__env->startSection('content'); ?>
<div class="main-body">
    <div class="page-wrapper">
        <!-- Page-header start -->
        <div class="page-header card">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ti-arrow-left bg-c-blue"></i>
                        <div class="d-inline">
                            <h4>Add New Place</h4>
                            <span>Here You Can Craete A New Place </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="page-header-breadcrumb">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admin')); ?>">
                                    <i class="icofont icofont-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Place</a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Add Place</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('Admin.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <!-- Page body start -->
        <div class="page-body">
            <div class="row">
                <div class="col-sm-12">
                    <!-- Basic Form Inputs card start -->
                        <div class="card">
                            <div class="card-block">
                                <h4 class="sub-title">Enter Basic Information</h4>
                                <form method="POST" action="<?php echo e(route('Place.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="placeName"
                                                placeholder="Title" value="<?php echo e(old('title')); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                                <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                                    <i class="fa fa-picture-o"></i> Choose
                                                </a>
                                            </span>
                                            <input id="thumbnail" class="form-control" type="text" name="image">
                                        </div>
                                        <div id="holder" style="margin-top:15px;max-height:100px;"></div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                            <label for="description">Description</label>
                                            <textarea id="description" name="Details"  class="form-control" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <select  class="form-control" name="size" >
                                                <option value=" " >--Category--</option>
                                                <option value="S" <?php echo e(old('size') == 'S' ? 'selected' : ' '); ?>>Small</option>
                                                <option value="M" <?php echo e(old('size') == 'M' ? 'selected' : ' '); ?>>Medium</option>
                                                <option value="L" <?php echo e(old('size') == 'L' ? 'selected' : ' '); ?>>Large</option>
                                                <option value="X" <?php echo e(old('size') == 'X' ? 'selected' : ' '); ?>>xLarge</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <select  class="form-control" name="size" >
                                                <option value=" " >--SubCategory--</option>
                                                <option value="S" <?php echo e(old('size') == 'S' ? 'selected' : ' '); ?>>Small</option>
                                                <option value="M" <?php echo e(old('size') == 'M' ? 'selected' : ' '); ?>>Medium</option>
                                                <option value="L" <?php echo e(old('size') == 'L' ? 'selected' : ' '); ?>>Large</option>
                                                <option value="X" <?php echo e(old('size') == 'X' ? 'selected' : ' '); ?>>xLarge</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <input class="form-control" type="number" step="any" name="from" placeholder="Work Time From" value="<?php echo e(old('price')); ?>">
                                        </div>                                       
                                        <div class="col-sm-6">
                                            <input class="form-control" step="any" type="number" name="to" placeholder="Work Time To" value="<?php echo e(old('discount')); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="phoneNumber"
                                                placeholder="Phone Number" value="<?php echo e(old('phoneNumber')); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <select id="cat_id"  class="form-control" name="regionId" >
                                                <option value="">--Region--</option>
                                                <?php $__currentLoopData = \App\Models\Region::where('isParent' , 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <select name="child_cat_id" id="child_cat_id"  class="form-control d-none">
                                                
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row text-right">
                                        <div class="col-sm-12">
                                            <input  style="width: 25%"  type="submit" class="btn btn-primary" value="Save">
                                            <input   style="width: 25%"  type="button" class="btn btn-info" value="Cancel">
                                        </div>   
                                    </div>
                                </form>    
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- Page body end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
        $('#lfm').filemanager('image');
</script>
<script>
     $(document).ready(function() {
        $('#description').summernote();});
</script>
<script>
    $(document).ready(function() {
       $('#summary').summernote();
});
</script>

<script>
    $('#cat_id').change(function(){
        var html_option = `<option value="">--Street--</option>`;
        var cat_id = $(this).val();
        // alert(cat_id);
        if(cat_id != null){
            $.ajax({
                url : "/admin/category/"+cat_id+"/child",
                type : "Post" ,
                data : {
                    _token : "<?php echo e(csrf_token()); ?>",
                    id:cat_id,
                },
                success:function(response) {
                    if (response.status) {
                        $('#child_cat_id').removeClass('d-none');
                        $.each(response.data , function(id , title){
                            html_option += `<option value='`+id+`'>`+title+`</option>`
                        }); 
                    } else {
                        $('#child_cat_id').addClass('d-none');
                    }
                    $('#child_cat_id').html(html_option);
                }
            });
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/product/create.blade.php ENDPATH**/ ?>