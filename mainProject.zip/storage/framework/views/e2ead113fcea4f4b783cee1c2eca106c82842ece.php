
<?php $__env->startSection('content'); ?>
<div class="main-body">
    <div class="page-wrapper">
        <!-- Page-header start -->
        <div class="page-header card">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                       <a href="<?php echo e(route('region.Add')); ?>"> <i class="ti-plus bg-c-blue"></i></a>
                        <div class="d-inline">
                            <h4>Show All Region and Street</h4>
                            <span class="badge badge-primary text-white">Total Regions : <?php echo e(App\Models\Region::all()->count()); ?> </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="page-header-breadcrumb">
                       <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin')); ?>">
                                <i class="icofont icofont-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Region</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">All Regions</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <!-- Page-body start -->
    <div class="page-body">
        <!-- Hover table card start -->
        <div class="card">
            <div class="card-header">
                <h5>Regions table</h5>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="icofont icofont-simple-left "></i></li>        
                        <li><i class="icofont icofont-maximize full-card"></i></li>        
                        <li><i class="icofont icofont-minus minimize-card"></i></li>        
                        <li><i class="icofont icofont-refresh reload-card"></i></li>        
                    </ul>
                </div>
            </div>
            <div class="card-block table-border-style">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>S.N</th>
                                <th>Name</th>
                                <th>is_Parent</th>
                                <th>Parent</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($region->name); ?></td>
                                <td><?php echo e($region->isParent); ?></td>
                                <td>
                                    <?php echo e($region->getAllStreetByRegion($region->parentId)->name); ?>

                                </td>
                                <td>
                                        <input value="<?php echo e($region->id); ?>" name="toggle" type="checkbox" data-toggle="toggle" data-on="Active" data-off="unActive" data-onstyle="success" data-offstyle="danger" data-size='xs' <?php echo e($region->status == 'active'? 'checked' : ' '); ?> ></td>
                                <td class="d-flex">
                                    <a href="<?php echo e(route('region.edit' , $region->id)); ?>" class='btn btn-sm btn-outline-warning  p-2 mx-1 ' data-toggle="tooltip" title="edit" data-placement = "bottom"><i class="ti-pencil "></i></a>
                                    <form action="<?php echo e(route('region.delete' , $region->id)); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a id="BtnDelet" class='btn btn-sm btn-outline-danger p-2 mx-1' data-id ="<?php echo e($region->id); ?>" data-toggle="tooltip" title="delete" data-placement = "bottom">
                                        <i class="ti-trash"></i></a>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Hover table card end -->
    </div>
    <!-- Page-body end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
     $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }   
    });
    $('#BtnDelet').click(function (e) {
        var form = $(this).closest('form');
        var dataID = $(this).data('id');
        e.preventDefault();
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true})
                .then((willDelete) => {
                if (willDelete)
                {
                    form.submit();
                    swal("Poof! Your imaginary file has been deleted!", {
                    icon: "success"});
                } 
                else
                {
                    swal("Your imaginary file is safe!");
                }
        });
        });
</script>


<script>
        $('input[name=toggle]').change(function(){
            var mode = $(this).prop('checked');
            var id  = $(this).val();
            // alert(id);
            $.ajax({
                url: "<?php echo e(route('region.status')); ?>",
                type : 'post' ,
                data : {
                    _token : '<?php echo e(csrf_token()); ?>',
                    mode : mode,
                    id : id,
                },
                success:function(response){
                    if(response.status){
                    alert(response.msg);
                    }else{
                        alert('Please Try Again');
                    }
                }
            });
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/region/index.blade.php ENDPATH**/ ?>