<?php if(Session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" id="alert" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <?php echo e(Session('success')); ?>

</div>
<?php endif; ?>
<?php if(Session('errors')): ?>

<div class="alert alert-danger alert-dismissible fade show" id="alert" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 
  </div>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/layouts/flash.blade.php ENDPATH**/ ?>