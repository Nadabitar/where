
<?php $__env->startSection('content'); ?>
<div class="main-body">
    <div class="page-wrapper">
        <!-- Page-header start -->
        <div class="page-header card">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ti-arrow-left bg-c-blue"></i>
                        <div class="d-inline">
                            <h4>Edit  Category</h4>
                            <span>Here You Can Edite Category </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="page-header-breadcrumb">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admin')); ?>">
                                    <i class="icofont icofont-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Category</a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Edit Category</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('Admin.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <!-- Page body start -->
        <div class="page-body">
            <div class="row">
                <div class="col-sm-12">
                    <!-- Basic Form Inputs card start -->
                        <div class="card">
                            <div class="card-block">
                                <h4 class="sub-title">Update  Information</h4>
                                <form method="POST" action="<?php echo e(route('category.update' , $category->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                            <div class="drag-image">
                                                <?php if($category->svg): ?>
                                                <img src="<?php echo e($category->svg); ?>" alt="image">
                                                <a onClick ="deleteImage()" class="drop_button" href="#"><i class="fa fa-trash"></i></a>
                                                <?php else: ?>
                                                <div class="icon"><i class="fas fa-cloud-upload-alt"></i></div>
                                                <h6>Drag & Drop File Here</h6>
                                                <a class="drop_button" href="#"><i class="fa fa-trash"></i></a>  
                                                <?php endif; ?>
                                            </div> 
                                        <div class="input-group">
                                            <input id="img-place" class="form-control" type="file" name="image">
                                        </div>
                                        
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" name="name"
                                                placeholder="Title" value="<?php echo e($category->name); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <label for="isParent">Is_Parent</label>
                                            <input type="checkbox" name="isParent" id="isParent" <?php echo e($category->isParent == 'true' ? 'checked' : " "); ?>>
                                        </div>
                                        <div class="col-sm-8" >
                                            <select id="parent_cat_id"  class="form-control" name="parentId" disabled>
                                                <option >--Parent Id--</option>
                                                <option selected><?php echo e(App\Models\Categoris::where('id' , $category->parentId)->value('name')); ?></option>
                                                <?php $__currentLoopData = App\Models\Categoris::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" ><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <select  class="form-control" name="status" >
                                                            <option value="">--Status--</option>
                                                            <option value="active" <?php echo e($category->status == 'active' ? 'selected' : ' '); ?>>active</option>
                                                            <option value="unactive" <?php echo e($category->status== 'unactive' ? 'selected' : ' '); ?>>unActive</option>
                                                        </select>
                                                    </div>
                                    </div>
                                    <div class="form-group row text-right">
                                        <div class="col-sm-12">
                                            <input  style="width: 25%"  type="submit" class="btn btn-primary" value="update">
                                            <input   style="width: 25%"  type="button" class="btn btn-info" value="Cancel">
                                        </div>   
                                    </div>
                                </form>    
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- Page body end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
        $('#lfm').filemanager('image');
</script>
<script>
     $(document).ready(function() {
        $('#summernote').summernote();
});
</script>
<script>
    $('#isParent').change(function(){
        var is_active = $(this).prop('checked');
        // alert(is_active);
        if (is_active) {
            $('#parent_cat_id').prop('disabled' , false);
        }else{
            $('#parent_cat_id').prop('disabled' , true);
        }

    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/Admin/category/edite.blade.php ENDPATH**/ ?>