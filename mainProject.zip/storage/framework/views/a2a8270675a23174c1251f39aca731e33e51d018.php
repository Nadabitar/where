

<?php $__env->startSection('header'); ?>
<link href="<?php echo e(asset('assets/css/subscriber/profile.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('subscriber.partial.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="info-page">
        <div class="info">
            <div class="row p-0 m-0">
                <div class="col-md-7">
                        <div class="container">
                            <div class="drag-image mt-5">
                                <div class="icon"><i class="fas fa-cloud-upload-alt"></i></div>
                                <h6>Drag & Drop File Here</h6>
                            </div>
                            
                            <div class="row">
                                <form enctype="multipart/form-data"   action="<?php echo e(route('Place.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="checkbox-form" dir="rtl">						
                                            <h3>إضافة تفاصيل المكان</h3>
                                            <div class="row">
                                                <div class="col-md-12 checkbox-line ">
                                                    <div class="checkout-form-list">
                                                        <label>image</label>
                                                        <input  type="file" name="image" id="img-place">
                                                    </div>  
                                                </div>
                                                <div class="col-md-12 checkbox-line ">
                                                    <div class="checkout-form-list">
                                                        <label>الصنف التابع له المكان <span class="required">*</span></label>
                                                        <select id="category" name="categoryId">
                                                            <?php $__currentLoopData = \App\Models\Categoris::where( 'isParent' ,true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select> 										
                                                    </div>
                                                </div>
                                                <div id="sub-category-box" class="col-md-12 checkbox-line   d-none">
                                                    <div class="country-select">
                                                        <label>الصنف الفرعي <span class="required">*</span></label>
                                                        <select  id="sub-category" name="subCategoryId">
                                                            
                                                        </select> 										
                                                    </div>
                                                </div>
                                                <div class="col-md-12 checkbox-line ">
                                                    <div class="checkout-form-list">
                                                        <label>اسم المكان</label>
                                                        <input name="placeName" type="text" placeholder="اسم المكان" />
                                                        <?php $__errorArgs = ['placeName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 checkbox-line ">
                                                    <div class="checkout-form-list">
                                                        <label>رقم الهاتف <span class="required">*</span></label>
                                                        <input type="text" placeholder="رقم الهاتف" name="phoneNumber" />
                                                        <input style="margin: 15px 8px" type="text" name="addtionalPhone" placeholder="هل هناك رقم تواصل أخر!!" />
                                                        <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">
                                                        <label>وقت العمل <span class="required">*</span></label>										
                                                        <input type="text" placeholder="من" name="from" />
                                                        <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">	
                                                        <label>وقت العمل <span class="required">*</span></label>								
                                                        <input type="text" placeholder="إلى" name="to" />
                                                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">
                                                        <label> الواتس آب</label>										
                                                        <input name="whats" type="text" placeholder="  آب/رابط مجموعة" />
                                                        <?php $__errorArgs = ['whats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">
                                                        <label>فيسبوك </label>										
                                                        <input name="facebook" type="text" placeholder="فيسبوك " />
                                                        <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">
                                                        <label>انستغرام</label>										
                                                        <input name="instagram" type="text" placeholder="انستغرام" />
                                                        <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 checkbox-line" >
                                                    <div class="checkout-form-list">	
                                                        <label> تفاصيل  <span class="required">*</span></label>								
                                                        <input type="text" placeholder="تفاصيل" name="details" />
                                                        <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>											
                                        </div>
                                    </div>	
                                    <div class="save-button">
                                        <input type="submit" value="حفظ" />
                                    </div>		
                                </form>
                            </div>
    
                        </div>
                </div>


                
                <div class="col-md-5 p-0">
                    <div class="background-page">Right</div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- google map api -->
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_qDiT4MyM7IxaGPbQyLnMjVUsJck02N0"></script>
    <script>
        var myCenter=new google.maps.LatLng(30.249796, -97.754667);
        function initialize()
        {
            var mapProp = {
                center:myCenter,
                scrollwheel: false,
                zoom:15,
                mapTypeId:google.maps.MapTypeId.ROADMAP
            };
            var map=new google.maps.Map(document.getElementById("hastech"),mapProp);
            var marker=new google.maps.Marker({
                position:myCenter,
                animation:google.maps.Animation.BOUNCE,
                icon:'assets/img/map-marker.png',
                map: map,
            });
            var styles = [
                {
                    stylers: [
                        { hue: "#c5c5c5" },
                        { saturation: -100 }
                    ]
                },
            ];
            map.setOptions({styles: styles});
            marker.setMap(map);
        }
        google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <script src="<?php echo e(asset('assets/js/Subscriber/info.js')); ?>"></script>   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('subscriber.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mainProject\resources\views/subscriber/pages/info.blade.php ENDPATH**/ ?>