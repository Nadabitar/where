<footer class="footer-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 col-sm-5">
                <div class="footer-logo">
                    <a href="#"><img src="assets/img/logo/logo.png" alt=""></a>
                    <p>Lorem ipsum dolor sit amet tempor, consectetur adipisicing.</p>
                    <ul>
                        <li><a href="https://www.facebook.com/devitems/?ref=bookmarks"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/devitemsllc"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.google.com/"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://www.instagram.com/devitems/"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-7 col-sm-7">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="footer-title res-mrg">
                            <h3>categories</h3>
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="shop.html"> Clothing</a></li>
                                    <li><a href="shop.html"> Shoes</a></li>
                                    <li><a href="shop.html">Watches</a></li>
                                    <li><a href="shop.html">Jewelry</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="footer-title res-mrg">
                            <h3>Support</h3>
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="#">Careers</a></li>
                                    <li><a href="#">Sale products</a></li>
                                    <li><a href="#">Terms & Condition</a></li>
                                    <li><a href="#">Delivery Inforamtion</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 hidden-sm">
                        <div class="footer-title res-mrg">
                            <h3>Quick Links</h3>
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="wishlist.html">Wishlist</a></li>
                                    <li><a href="cart.html">My Cart</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12">
                <div class="footer-title res-mrg-2">
                    <h3>newsletter</h3>
                    <div class="footer-newsletter">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et.</p>
                        <div id="mc_embed_signup" class="subscribe-form">
                            <form action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                <div id="mc_embed_signup_scroll" class="mc-form">
                                    <input type="email" value="" name="EMAIL" class="email" placeholder="Your email address" required>
                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                    <div class="mc-news" aria-hidden="true"><input type="text" name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" tabindex="-1" value=""></div>
                                    <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="footer-bottom text-center ptb-20">
            <p>
                © 2017
                <a href="https://freethemescloud.com/" target="_blank">Free themes Cloud</a>
                . All Rights Reserved.
            </p>
        </div>
    </div>
</footer>